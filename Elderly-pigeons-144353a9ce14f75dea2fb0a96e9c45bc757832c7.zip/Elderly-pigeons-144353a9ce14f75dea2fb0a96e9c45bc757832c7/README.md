# Elderly-pigeons
Project from our (with sergeypospelov and Yurafobus1) team at spring 2020.

Для установки библиотеки expat надо в командной строке ввести:

`sudo apt-get install libexpat1-dev`

install SFML

`sudo apt-get install libsfml-dev`

Для того, чтобы сразу же работало с CMake без проблем, нужно установить SFML версии 2.5.1.