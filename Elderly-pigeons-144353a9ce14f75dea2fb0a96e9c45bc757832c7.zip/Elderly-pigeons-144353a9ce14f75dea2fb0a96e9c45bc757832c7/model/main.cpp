/*
#include "game.hpp"

int main()
{
	std::string s, t;
	std::cin >> s >> t;
	Game game;
	game.load_from_file(s);
	game.move(FIRST, board_cell(5, 0), board_cell(4, 1));
	game.save_to_file(t);
	return 0;
}
*/
